package com.bootexample1.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bootexample1.domain.Employee;

public interface EmpRepo extends CrudRepository<Employee, Long> {
	
	//@Query(name = "select * from employee", nativeQuery = true)
	//public List<Employee> fetchAllEmployee();
	
	@Query(name = "select * from employee where EID= ?1", nativeQuery = true)
	public Optional<Employee> findById(Long id);
	
	

}
