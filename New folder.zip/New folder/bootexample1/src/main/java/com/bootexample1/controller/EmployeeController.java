package com.bootexample1.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bootexample1.domain.Employee;
import com.bootexample1.service.EmployeeServiceImpl;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeServiceImpl employeeServiceImpl;
	
	@GetMapping("/fetchAllEmployees")
	public ResponseEntity<Employee> getAllEmployees(){
		List<Employee> emplLst = new ArrayList<Employee>();
		Optional<Employee> emp = employeeServiceImpl.fetchAllEmp();
		return new ResponseEntity<>(emp.get(),HttpStatus.OK);
	}

}
