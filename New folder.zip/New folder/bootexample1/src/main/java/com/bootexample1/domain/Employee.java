package com.bootexample1.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude
@JsonIgnoreProperties
@Entity
@Table(name = "EMPLOYEE")
public class Employee {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EID")
	private Long id;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "PHONE_NUMBER")
	private Long phoneNumber;
}
