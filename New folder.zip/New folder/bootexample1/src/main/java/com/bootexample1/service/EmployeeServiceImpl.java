package com.bootexample1.service;

import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bootexample1.domain.Employee;
import com.bootexample1.repository.EmpRepo;

@Service
@Transactional
public class EmployeeServiceImpl {
	
	@Autowired
	DataSource dataSource;
	
	@Autowired
	EmpRepo empRepo;
	
	public Optional<Employee> fetchAllEmp(){
		System.out.println("all end");
		 return  empRepo.findById(11L);
		//return empRepo.fetchAllEmployee();
	}
	
	public List<Employee> fetchAllEmps(){
		System.out.println("all start");
		 return  (List<Employee>) empRepo.findAll();
		
	}

	public long fetchCount(){
		System.out.println( empRepo.count());
		 return empRepo.count();
	}

}
